package it.sella.com;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

public class CourseCodeConstraintValidator implements ConstraintValidator<CourseCode,String>{

	private String courseCode;
	
	@Override
	public void initialize(CourseCode theCode) {
		courseCode = theCode.value();
	}

	@Override
	public boolean isValid(String theCode, ConstraintValidatorContext constraintValidatorContext) {
			boolean result;
			if(theCode != null) {
				result = theCode.startsWith(courseCode);
			}else {
				result = true;
			}
			
		return result;
	}

	
}
