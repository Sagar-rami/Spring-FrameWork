package it.com.client;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import it.com.beans.Student;
import it.com.dao.StudentDao;

public class ClientApplication {

	public static void main(String[] args) {
		
		ApplicationContext context = new ClassPathXmlApplicationContext("SpringApplication.xml");
		StudentDao stud_dao = (StudentDao)context.getBean("sdao");
		stud_dao.persistStudent(new Student(555,"Poornima",89));
		
	}
}
