package it.com.client;

import java.util.Scanner;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import it.com.beans.Student;
import it.com.dao.StudentDao;

public class ClientApplication {

	public static void main(String[] args) {
		
		ApplicationContext context = new ClassPathXmlApplicationContext("SpringApplication.xml");
		StudentDao studentDao = (StudentDao)context.getBean("sdao");
		
		Scanner scanner = new Scanner(System.in);
		
		System.out.println("Enter Student ID :: ");
		int sid = scanner.nextInt();
		System.out.println("Enter Student Name :: ");
		String sname = scanner.next();
		System.out.println("Enter Student Marks :: ");
		int marks = scanner.nextInt();
		System.out.println("sid ::"+sid+"sname ::"+sname+"marks ::"+marks);
		Student student = new Student(sid,sname,marks);
		int noOfRows = studentDao.persistStudent(student);
		System.out.println("Number of Rows inserted :: "+noOfRows);
		
	}
}
