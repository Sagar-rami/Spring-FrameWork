package it.sella.com;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.dao.DataAccessException;

public class InsertStudent {

	public static void main(String[] args) {
		
		ApplicationContext context = new ClassPathXmlApplicationContext("SpringApplication.xml");
		StudentDao dao = null;
		try {
			dao = context.getBean("sdao",StudentDao.class);
			dao.saveStudent(new Student(1040,"Madan",68));
			System.out.println("Record Inserted");
			List<Student> studList = dao.getStudents();
			for (Student student : studList) {
				System.out.println("Student ID :: "+student.getSid()+" // Student Name :: "+student.getSname()+" //  Student Marks :: "+student.getMarks());
			}
		}catch(DataAccessException e) {
			System.out.println("SQLException is raised ");
		}
		
	}
}
