package it.com;

public interface Employee {

	public String getEmpName();
}

/**
# If we have multiple implementations for an interface then there will be a confusion faced by Spring container 
in choosing a bean using Autowiring.

# In our example, if Employee interface do have mulitple implementations then probably it raises an exception
named "NoUniqueBeanDefinitionException" rasied from the class of spring 
																				--> org.springframework.beans.factory.NoUniqueBeanDefinitionException

# In order to solve this problem we need to indicate Spring container that which bean it need to choose for autowiring, 
with the help of an annotaion named --> @Qualifier("beanId")

 # @Qualifier --> annotation can be used on 
  									Constructor Injection
  									Setter injection
  									Filed injection
*/