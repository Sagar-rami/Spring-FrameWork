package it.cogni.com.dao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import it.cogni.com.bean.Student;

@Component
public class StudentDAO {
	
	private Student student;

	public List<Student> findStudents(){
		List<Student> studentsList = new ArrayList<Student>();
		Student student1 = new Student(100,"Kiran");
		Student student2 = new Student(101,"Rajesh");
		Student student3 = new Student(102,"Praveen");
		studentsList.add(student1);
		studentsList.add(student2);
		studentsList.add(student3);
		return studentsList;
	}
	
	public void printInfo() {
		System.out.println("This is a printInfo() method of StudentDAO class ");
	}
	
}
