package it.com;

import java.util.Random;

import org.springframework.stereotype.Component;

@Component
public class RandomEmpName implements Employee{

	//create an array of Strings
	private String[] empName = {
			"Kiran","Praveen","Sharma","Varun","Albina","Sagar"
     };
	
	// Generating a random number
	private Random random = new Random();
	
	
	@Override
	public String getEmpName() {
		return empName[random.nextInt(empName.length)];
	}

}
