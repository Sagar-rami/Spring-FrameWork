package it.com;

import org.springframework.stereotype.Component;

@Component
public class SalesEmpImpl implements Employee{

	@Override
	public String getEmpName() {
		return "Nagaraj";
	}

}
