package com;

public class SampleB {

	public SampleB() {
		System.out.println("SampleB class no - arg constructor");
	}
	
	public void display() {
		System.out.println("SampleB class display() method");
	}
}
