package it.com;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

@Component
public class DepartmentImpl implements Department{

	/*@Autowired
	@Qualifier(value="salesEmpImpl")*/
	private Employee employee;
	
	@Autowired
	public DepartmentImpl(@Qualifier(value="randomEmpName")Employee employee) {
		this.employee = employee;
	}
	

	@Override
	public String getDeptName() {
		return "Sales";
	}

	@Override
	public String getEmpName() {
		return employee.getEmpName();
	}

	
}
