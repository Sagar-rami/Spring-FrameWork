package it.cogni.com.aspect;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import it.cogni.com.bean.Student;

@Aspect
@Component
@Order(3)
public class MyFirstAspect {

	@Pointcut("execution(* it.cogni.com.dao.StudentDAO.add*(..))")
	private void onAddMethodsOfStudent() {}
	
	@Pointcut("execution(* it.cogni.com.dao.CollegeDAO.add*(..))")
	private void onAddMethodsOfCollege() {}
	
	@Before("onAddMethodsOfStudent()")
	public void beforeAddStudentAdvice(JoinPoint theJoinPoint) {
		MethodSignature signiture = (MethodSignature)theJoinPoint.getSignature();
		System.out.println("Method :: "+signiture);		
		System.out.println("##########################");
		Object[] args = theJoinPoint.getArgs();
		for(Object object : args) {
			System.out.println(object);
			if(object instanceof Student) {
				Student student = (Student)object;
				System.out.println("Student Name :: "+student.getSname());
			}
		}
		System.out.println("\n ==> This Advice should be in the first order of execution on StudentDAO business methods ");
	}
	
	@Before("onAddMethodsOfCollege()")
	public void beforeAddCollegeAdvice() {
		System.out.println("\n ==> This Advice should be in the first order of execution on StudentDAO business methods ");
	}
	
}
