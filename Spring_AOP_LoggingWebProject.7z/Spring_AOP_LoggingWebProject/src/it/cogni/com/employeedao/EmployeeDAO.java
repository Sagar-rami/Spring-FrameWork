package it.cogni.com.employeedao;

import java.util.List;

import it.cogni.com.beans.Employee;

public interface EmployeeDAO {

	public List<Employee> getEmployees();
	public void addEmployee(Employee employee);
	public Employee getEmployee(int empid);
	public void deleteEmployee(int empid);
	
}
