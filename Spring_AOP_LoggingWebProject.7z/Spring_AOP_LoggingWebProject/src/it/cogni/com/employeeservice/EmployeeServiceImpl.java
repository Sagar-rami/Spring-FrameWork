package it.cogni.com.employeeservice;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import it.cogni.com.beans.Employee;
import it.cogni.com.employeedao.EmployeeDAOImpl;

@Service
public class EmployeeServiceImpl implements EmployeeService{

	@Autowired
	private EmployeeDAOImpl employeeDAOImpl;
	
	@Override
	@Transactional
	public List<Employee> getEmployees() {
		return employeeDAOImpl.getEmployees();
	}

	@Override
	@Transactional
	public void addEmployee(Employee employee) {
		employeeDAOImpl.addEmployee(employee);
	}

	@Override
	@Transactional
	public Employee getEmployee(int empid) {
		return employeeDAOImpl.getEmployee(empid);
	}

	@Override
	@Transactional
	public void deleteEmployee(int empid) {
		employeeDAOImpl.deleteEmployee(empid);	
	}
}
