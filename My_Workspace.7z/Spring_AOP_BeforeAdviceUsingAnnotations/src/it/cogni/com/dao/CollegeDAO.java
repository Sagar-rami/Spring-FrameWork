package it.cogni.com.dao;

import org.springframework.stereotype.Component;

@Component
public class CollegeDAO {

	public void addStudent() {
		System.out.println(getClass() + "   ::  Adding student in College ");
	}
	
	public String addCollegeLibrarian(boolean flag) {
		System.out.println(getClass() + " :: College Librarian is added " );
		
		return "Librarian";
	}
	
	public void addCollegeLibrarian(String name,boolean flag) {
		System.out.println(getClass()+" :: Librarian Name :: "+name);
	}
	
	protected void addRegister() {
		System.out.println("This is a protected modified method ");
	}
	
}
