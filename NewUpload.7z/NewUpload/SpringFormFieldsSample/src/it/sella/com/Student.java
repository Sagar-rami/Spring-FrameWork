package it.sella.com;

import java.util.Map;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

public class Student {

	private String firstName;
	
	@NotNull(message = "is Required")
	@Size(min=1,message = "is Required")
	private String lastName;
	
	private String country;
	private String favLanguage;
	private String[] operatingSystems;
	
	
	
	public String[] getOperatingSystems() {
		return operatingSystems;
	}

	public void setOperatingSystems(String[] operatingSystems) {
		this.operatingSystems = operatingSystems;
	}

	public String getFavLanguage() {
		return favLanguage;
	}

	public void setFavLanguage(String favLanguage) {
		this.favLanguage = favLanguage;
	}

	private Map<String,String> countryMap;
	
	public String getCountry() {
		return country;
	}

	public Student(String firstName, String lastName, String country) {
		this.firstName = firstName;
		this.lastName = lastName;
		this.country = country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public Student() {
		
		//populate country code using ISO - country code
		/*countryMap = new LinkedHashMap<>();
		countryMap.put("BR", "Brazil");
		countryMap.put("IN", "India");
		countryMap.put("CR", "France");
		countryMap.put("DE", "Germany");
		*/
	}

	public Map<String, String> getCountryMap() {
		return countryMap;
	}

	public void setCountryMap(Map<String, String> countryMap) {
		this.countryMap = countryMap;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public Student(String firstName, String lastName) {
		this.firstName = firstName;
		this.lastName = lastName;
	}

	@Override
	public String toString() {
		return "Student [firstName=" + firstName + ", lastName=" + lastName + ", country=" + country + ", favLanguage="
				+ favLanguage + "]";
	}
	
	
	
}
