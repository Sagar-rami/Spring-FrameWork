package it.cogni.com.client;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import it.cogni.com.config.StudentConfig;
import it.cogni.com.dao.StudentDAO;

public class MainClientApplication {

	public static void main(String[] args) {
		
		//read spring config java class
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext(StudentConfig.class);
		
		//get the bean from spring container
		StudentDAO studentDao = context.getBean("studentDAO",StudentDAO.class);
		
		//call the business method
		studentDao.addStudent();
		
		//lets call the addStudent() method again to check if the aspect is called again or not
		//studentDao.addStudent();
		
		//close the context
		context.close();
		
	}
}
