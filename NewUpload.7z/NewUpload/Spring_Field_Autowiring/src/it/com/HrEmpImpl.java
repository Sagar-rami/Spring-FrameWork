package it.com;

import org.springframework.stereotype.Component;

@Component
public class HrEmpImpl implements Employee{

	@Override
	public String getEmpName() {
		return "Swetha";
	}

}
