package it.com;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class ClientApplication {

	public static void main(String[] args) {
		
		ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("Spring_ApplicationContext.xml");
		
		Department department = context.getBean("departmentImpl",DepartmentImpl.class);
		System.out.println(department.getDeptName());
		System.out.println(department.getEmpName());
		
		System.out.println("==================================================");
		
		EmployeeDetails empDet = context.getBean("employeeDetails",EmployeeDetails.class);
		System.out.println("Employee name :: "+empDet.getEmpName());
		System.out.println("Employee Department :: "+empDet.getDeptName());
		System.out.println("Employee Common Email :: "+empDet.getCmpnyEmail());
		System.out.println("Employee Common Tag :: "+empDet.getCmpnyTag());
		
	}
}
