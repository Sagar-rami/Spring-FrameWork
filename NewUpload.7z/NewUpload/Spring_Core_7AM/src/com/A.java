package com;

import java.util.Date;

public class A {

	public A() {
		System.out.println("A class user defined constructor");
	}
	
	//Non - static factory method
	public Date getDate() {
		return new Date();
	}
	
	//Factory method returnig object of B class 
	public B getB() {
		return new B();
	}
	
	public String display() {
		return "Simple display method of A class";
	}
	
}
