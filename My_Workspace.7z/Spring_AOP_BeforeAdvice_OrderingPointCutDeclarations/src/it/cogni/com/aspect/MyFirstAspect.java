package it.cogni.com.aspect;

import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

@Aspect
@Component
@Order(3)
public class MyFirstAspect {

	@Pointcut("execution(* it.cogni.com.dao.StudentDAO.add*(..))")
	private void onAddMethodsOfStudent() {}
	
	@Pointcut("execution(* it.cogni.com.dao.CollegeDAO.add*(..))")
	private void onAddMethodsOfCollege() {}
	
	@Before("onAddMethodsOfStudent()")
	public void beforeAddStudentAdvice() {
		System.out.println("\n ==> This Advice should be in the first order of execution on StudentDAO business methods  ************** ");
	}
	
	@Before("onAddMethodsOfCollege()")
	public void beforeAddCollegeAdvice() {
		System.out.println("\n ==> This Advice should be in the first order of execution on StudentDAO business methods ");
	}
	
}
