package it.sella.com;

import java.util.ArrayList;
import java.util.List;

import org.springframework.orm.hibernate3.HibernateTemplate;

public class StudentDao {

	HibernateTemplate template;
	//instead using HibernateTemplate object we can also extend "HibernateDaoSupport" class for getting 
	//HibernateTemplate object

	public HibernateTemplate getTemplate() {
		return template;
	}

	public void setTemplate(HibernateTemplate template) {
		this.template = template;
	}

	public void saveStudent(Student s){  
	    template.save(s);  
	}  
	
	public List<Student> getStudents(){  
	    List<Student> list=new ArrayList<Student>();  
	    list=template.loadAll(Student.class);  
	    return list;  
	}  
	
}
