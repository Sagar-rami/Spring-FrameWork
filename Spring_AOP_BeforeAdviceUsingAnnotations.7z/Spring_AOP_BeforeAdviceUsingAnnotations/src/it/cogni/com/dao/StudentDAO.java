package it.cogni.com.dao;

import org.springframework.stereotype.Component;

@Component
public class StudentDAO {

	public void addStudent() {
		System.out.println(getClass() + " ::  Add DB Code for Student");
	}
}
