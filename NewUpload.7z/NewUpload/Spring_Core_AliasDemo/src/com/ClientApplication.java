package com;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

public class ClientApplication {

	public static void main(String[] args) {
		
		Resource r = new ClassPathResource("./springCore.xml");
		BeanFactory factory = new XmlBeanFactory(r);
		
		MessageBean message = (MessageBean)factory.getBean("msgBean");
		System.out.println(message.getMessage());
		
		MessageBean message1 = (MessageBean)factory.getBean("m1");
		MessageBean message2 = (MessageBean)factory.getBean("m2");
		MessageBean message3 = (MessageBean)factory.getBean("m3");
		System.out.println(message1.getMessage());
		System.out.println(message2.getMessage());
		System.out.println(message3.getMessage());
		
		String aliases[] = factory.getAliases("msgBean");
		for(String alias : aliases)
			System.out.println(alias);
		
		
	}
}
