package it.cogni.com.utils;

public interface QUERY_UTILS {

	public static final String INSERT_EMPLOYEE_REC="insert into employee_dump (empid,ename,salary,deptid,job_id,email) values (?,?,?,?,?,?)";
	public static final String SELECT_EMP_ON_EMPID = "select empid,ename,salary,deptid,job_id,email from employee_dump where empid = ?";
	public static final String SELECT_EMP_REC = "select empid,ename,salary,deptid,job_id,email from employee_dump";
	public static final String DELETE_EMP_REC = "delete from employee_dump where empid = ?";
	public static final String SELECT_MAX_ROWS = "select count(*) from employee_dump where empid = ?";
	public static final String UPDATE_EMP_REC = "update employee_dump set ename = ?,salary = ?,deptid = ?,job_id = ?,email = ? where empid = ?";
}
