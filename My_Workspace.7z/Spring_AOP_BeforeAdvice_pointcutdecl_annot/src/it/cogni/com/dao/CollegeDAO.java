package it.cogni.com.dao;

import org.springframework.stereotype.Component;

import it.cogni.com.bean.College;

@Component
public class CollegeDAO {

	College college;
	
	public void addStudent() {
		System.out.println(getClass() + "   ::  Adding student in College ");
	}
	
	public String addCollegeLibrarian() {
		System.out.println(getClass() + " :: College Librarian is added " );
		return "Librarian";
	}
	
	public void addCollege(College college) {
		this.college = college;
		System.out.println("A new detail about college is added");
	}
	
	public void printCollege() {
		System.out.println("Here are the college details");
		System.out.println("College ID is :: "+college.getColgeId());
		System.out.println("Branch name "+college.getBranchName());
	}
	
}
