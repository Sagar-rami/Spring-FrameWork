package it.cogni.com.employeedao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.stereotype.Repository;

import it.cogni.com.beans.Employee;
import it.cogni.com.utils.QUERY_UTILS;

@Repository
public class EmployeeDAOImpl extends JdbcDaoSupport implements EmployeeDAO {

		
	@Override
	public List<Employee> getEmployees() {
		return getJdbcTemplate().query(QUERY_UTILS.SELECT_EMP_REC, new RowMapper<Employee>() {
			@Override
			public Employee mapRow(ResultSet rs, int index) throws SQLException {
				Employee employee = new Employee();
				 employee.setEmpid(rs.getInt(1));
				 employee.setEname(rs.getString(2));
				 employee.setSalary(rs.getInt(3));
				 employee.setDeptid(rs.getInt(4));
				 employee.setJob_id(rs.getString(5));
				 employee.setEmail(rs.getString(6));
				 return employee;
			}});
	}

	@Override
	public void addEmployee(Employee employee) {
		Integer count = 0;
		count = getJdbcTemplate().queryForObject(QUERY_UTILS.SELECT_MAX_ROWS,new Object[] {employee.getEmpid()}, new RowMapper<Integer>() {
			@Override
			public Integer mapRow(ResultSet arg0, int arg1) throws SQLException {
				return arg0.getInt(1);
			}});
		System.out.println("COUNT = "+count);
		if(count == 0) {
				getJdbcTemplate().update(QUERY_UTILS.INSERT_EMPLOYEE_REC, new Object[] {employee.getEmpid(),
						employee.getEname(),employee.getSalary(),employee.getDeptid(),employee.getJob_id(),employee.getEmail()});
		}else {
			getJdbcTemplate().update(QUERY_UTILS.UPDATE_EMP_REC, new Object[] {
					employee.getEname(),employee.getSalary(),employee.getDeptid(),employee.getJob_id(),employee.getEmail(),employee.getEmpid()});
		}
	}

	@Override
	public Employee getEmployee(int empid) {
		
		return getJdbcTemplate().queryForObject(QUERY_UTILS.SELECT_EMP_ON_EMPID, new Object[] {empid}, new RowMapper<Employee>() {
			@Override
			public Employee mapRow(ResultSet rs, int index) throws SQLException {
				Employee employee = new Employee();
				employee.setEmpid(rs.getInt(1));
				 employee.setEname(rs.getString(2));
				 employee.setSalary(rs.getInt(3));
				 employee.setDeptid(rs.getInt(4));
				 employee.setJob_id(rs.getString(5));
				 employee.setEmail(rs.getString(6));
				 return employee;
			}
		});
	}

	@Override
	public void deleteEmployee(int empid) {
		getJdbcTemplate().update(QUERY_UTILS.DELETE_EMP_REC, new Object[] {empid});
	}

}
