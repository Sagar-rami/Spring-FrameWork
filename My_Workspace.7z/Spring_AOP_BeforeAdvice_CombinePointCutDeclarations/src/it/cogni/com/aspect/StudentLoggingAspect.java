package it.cogni.com.aspect;

import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.stereotype.Component;

@Aspect
@Component
public class StudentLoggingAspect {

	@Pointcut("execution(* it.cogni.com.dao.*.add*(..))")
	private void onaddMethods() {}
	
	@Pointcut("execution(* it.cogni.com.dao.*.printStudent*(..))")
	private void onprintStudent() {}
	
	@Pointcut("execution(* it.cogni.com.dao.*.printCollege*(..))")
	private void onprintCollege() {}
	
	@Pointcut("execution(* it.cogni.com.dao.*.*Info())")
	private void onPrintInfo() {}
	
	
	@Before("onaddMethods() && onPrintInfo()")    
	public void beforeAddStudentAdvice() {
		System.out.println("\n ==> Advice executes based on specific set of conditions on StudentDAO ########################### ");
	}
	
	@Before("onprintStudent() && !onprintCollege()")
	public void beforeStudentAnalytics() {
		System.out.println("\n ==>  Analysis of the student details branch wise called before print methods");
	}
	
}

