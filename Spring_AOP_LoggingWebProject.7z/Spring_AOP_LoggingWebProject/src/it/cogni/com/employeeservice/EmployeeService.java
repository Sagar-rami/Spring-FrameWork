package it.cogni.com.employeeservice;

import java.util.List;

import it.cogni.com.beans.Employee;

public interface EmployeeService {

	public List<Employee> getEmployees();
	public void addEmployee(Employee employee);
	public Employee getEmployee(int empid);
	public void deleteEmployee(int empid);
	
}
